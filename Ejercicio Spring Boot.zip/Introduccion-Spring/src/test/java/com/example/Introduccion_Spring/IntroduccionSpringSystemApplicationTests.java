package com.example.Introduccion_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroduccionSpringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
