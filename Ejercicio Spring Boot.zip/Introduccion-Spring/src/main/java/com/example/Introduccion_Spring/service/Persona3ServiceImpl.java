package com.example.Introduccion_Spring.service;

import com.example.Introduccion_Spring.domain.Persona3;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class Persona3ServiceImpl implements Persona3Service{

    List<Persona3> personas = new ArrayList<>(Arrays.asList(
            new Persona3( "00123456W","Pepe", "García", "Flores", LocalDate.of(1990, 5, 15),
                    "Masculino"),
            new Persona3( "00123457W","Jose", "Rodriguez", "Mendez", LocalDate.of(1997, 9, 15),
                    "Masculino"),
            new Persona3( "00123458W","María", "Castaño", "Dominguez", LocalDate.of(1999, 1, 14),
                    "Masculino"),
            new Persona3( "00123459W","Luis", "García", "Hernandez", LocalDate.of(1990, 5, 15),
                    "Masculino"),
            new Persona3( "00123451W","Pepe", "García", "Flores", LocalDate.of(1990, 5, 15),
                    "Masculino"),
            new Persona3( "00123450W","Jose", "Rodriguez", "Mendez", LocalDate.of(1997, 9, 15),
                    "Masculino"),
            new Persona3( "00123452W","María", "Castaño", "Dominguez", LocalDate.of(1999, 1, 14),
                    "Masculino"),
            new Persona3( "00123453W","Luis", "García", "Hernandez", LocalDate.of(1990, 5, 15),
                    "Masculino"),
            new Persona3( "00123454W","María", "Castaño", "Dominguez", LocalDate.of(1999, 1, 14),
                    "Masculino"),
            new Persona3( "00123455W","Luis", "García", "Hernandez", LocalDate.of(1990, 5, 15),
                    "Masculino")
    ));


    @Override
    public List<Persona3> getPersonas(){
        return personas;
    }
    @Override
    public void addPersona(Persona3 persona){
        personas.add(persona);
    }
}
