package com.example.Introduccion_Spring.controller;

import com.example.Introduccion_Spring.domain.Persona3;
import com.example.Introduccion_Spring.service.Persona3Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/personas3")
public class Persona3Controller {
    //Instancia de clase
    //Persona3ServiceImpl persona3Service = new Persona3ServiceImpl();
    @Autowired
    private Persona3Service persona3Service;

    @GetMapping
    public ResponseEntity<?> getPersonas(){
        List<Persona3> personas = persona3Service.getPersonas();
        return ResponseEntity.ok(personas);
    }

    //Obtener el dato de una persona con un DNI en específico
    @GetMapping("/{dni}")
    public ResponseEntity<?> getPersonas2(@PathVariable String dni){
        for(Persona3 p: persona3Service.getPersonas()){
            if(p.getDni().equalsIgnoreCase(dni)){
                return ResponseEntity.ok(p);
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Persona no encontrado con username: " + dni);
    }

    //Sobrescribir los datos de la persona encontrada
    @PutMapping
    public ResponseEntity<?>putPersonas2(@RequestBody Persona3 persona){

        for (Persona3 p: persona3Service.getPersonas()){
            if(p.getDni().equalsIgnoreCase(persona.getDni())){
                p.setDni(persona.getDni());
                p.setNombre(persona.getNombre());
                p.setPrimerApellido(persona.getPrimerApellido());
                p.setSegundoApellido(persona.getSegundoApellido());
                p.setFechaNacimiento(persona.getFechaNacimiento());
                p.setSexo(persona.getSexo());

                return ResponseEntity.ok("Persona modificado correctamente: "+persona.getNombreCompleto());
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Persona no encontrada: "+persona.getNombre());

    }



}
