package com.example.Introduccion_Spring.service;

import com.example.Introduccion_Spring.domain.Persona3;

import java.util.List;

public interface Persona3Service {

    public List<Persona3> getPersonas();
    public void addPersona(Persona3 persona);
}
