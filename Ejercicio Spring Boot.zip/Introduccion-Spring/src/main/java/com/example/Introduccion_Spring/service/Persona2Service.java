package com.example.Introduccion_Spring.service;

import com.example.Introduccion_Spring.domain.Persona2;

import java.util.List;

public interface Persona2Service {
    public List<Persona2> getPersonas();
    public void addPersona(Persona2 persona);
}
