package com.example.Introduccion_Spring.controller;

import com.example.Introduccion_Spring.domain.Persona1;
import com.example.Introduccion_Spring.service.Persona1Service;
import com.example.Introduccion_Spring.service.Persona1ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/personas1")
public class Persona1Controller {

    //Instancia de clase
    //Persona1ServiceImpl personaService = new Persona1ServiceImpl();
    @Autowired
    private Persona1Service persona1Service;

    @GetMapping
    public ResponseEntity<?> getPersonas(){
        List<Persona1> personas = persona1Service.getPersonas();
        return ResponseEntity.ok(personas);
    }



}
