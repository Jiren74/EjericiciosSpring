package com.example.Introduccion_Spring.service;

import com.example.Introduccion_Spring.domain.Persona1;

import java.util.List;

public interface Persona1Service {
    public List<Persona1> getPersonas();
}
