package com.example.Introduccion_Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntroduccionSpringSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntroduccionSpringSystemApplication.class, args);
	}

}
