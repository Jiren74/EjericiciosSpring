package com.example.Introduccion_Spring.service;

import com.example.Introduccion_Spring.domain.Persona1;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class Persona1ServiceImpl implements Persona1Service{

    List<Persona1> personas = new ArrayList<>(Arrays.asList(
            new Persona1( "Pepe", "García", "Flores", LocalDate.of(1990, 5, 15),
                    "Masculino"),
            new Persona1( "Jose", "Rodriguez", "Mendez", LocalDate.of(1997, 9, 15),
                    "Masculino"),
            new Persona1( "María", "Castaño", "Dominguez", LocalDate.of(1999, 1, 14),
                    "Masculino"),
            new Persona1( "Luis", "García", "Hernandez", LocalDate.of(1990, 5, 15),
                    "Masculino")
    ));

    @Override
    public List<Persona1> getPersonas(){
        return personas;
    }
}
