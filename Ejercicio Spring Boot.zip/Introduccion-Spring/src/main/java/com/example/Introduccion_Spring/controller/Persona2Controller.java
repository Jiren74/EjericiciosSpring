package com.example.Introduccion_Spring.controller;

import com.example.Introduccion_Spring.domain.Persona2;
import com.example.Introduccion_Spring.service.Persona2Service;
import com.example.Introduccion_Spring.service.Persona2ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/personas2")
public class Persona2Controller {

    //Instancia de clase
    //Persona2ServiceImpl persona2Service = new Persona2ServiceImpl();
    @Autowired
    private Persona2Service persona2Service;

    @GetMapping
    public ResponseEntity<?> getPersonas(){
        List<Persona2> personas = persona2Service.getPersonas();
        return ResponseEntity.ok(personas);
    }

    //Ejercicio 2: Post de una persona
    @PostMapping("/envioFormulario")
    public ResponseEntity<?> postCliente(@RequestParam(value="nombre") String nombre,
                                         @RequestParam (value="apellido1") String apellido1,
                                         @RequestParam (value="apellido2") String apellido2,
                                         @RequestParam (value="fechaNacimiento") LocalDate fecha,
                                         @RequestParam (value="sexo") String sexo){
        Persona2 persona = new Persona2(nombre, apellido1, apellido2, fecha, sexo);
        persona2Service.addPersona(persona);
        System.out.println(persona);
        return ResponseEntity.status(HttpStatus.CREATED).body("Persona creada exitosamente "+persona.getNombreCompleto());
    }


}
