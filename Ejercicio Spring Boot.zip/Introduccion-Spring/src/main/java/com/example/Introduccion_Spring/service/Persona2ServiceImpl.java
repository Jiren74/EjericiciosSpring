package com.example.Introduccion_Spring.service;

import com.example.Introduccion_Spring.domain.Persona2;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class Persona2ServiceImpl implements Persona2Service{
    List<Persona2> personas = new ArrayList<>(Arrays.asList(
            new Persona2( "Pepe", "García", "Flores", LocalDate.of(1990, 5, 15),
                    "Masculino"),
            new Persona2( "Jose", "Rodriguez", "Mendez", LocalDate.of(1997, 9, 15),
                    "Masculino"),
            new Persona2( "María", "Castaño", "Dominguez", LocalDate.of(1999, 1, 14),
                    "Masculino"),
            new Persona2( "Luis", "García", "Hernandez", LocalDate.of(1990, 5, 15),
                    "Masculino")
    ));

    @Override
    public List<Persona2> getPersonas(){
        return personas;
    }
    @Override
    public void addPersona(Persona2 persona){
        personas.add(persona);
    }
}
